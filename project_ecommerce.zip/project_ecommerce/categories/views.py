from django.http import HttpResponse
from django.shortcuts import render
from product_detail.models import Product_info

def f_ewomen(request):
    try:
        product = Product_info.objects.filter(ptype__contains="eyeglass")
        context = {'productlist': product}
        return render(request, 'categories/w_e_categories.html', context)
    except Product_info.DoesNotExist:
        return HttpResponse(request, " doesnot exist")


def f_swomen(request):
    try:
        product = Product_info.objects.filter(ptype__contains="sunglass")
        context = {'productlist': product}
        return render(request, 'categories/w_s_categories.html', context)
    except Product_info.DoesNotExist:
        return HttpResponse(request, " doesnot exist")

def f_women(request):
    return render(request,'categories/w_categories.html')