from . import  views
from django.urls import path

urlpatterns = [
    path('w_sunglass', views.f_swomen, name='women_sunglass'),
    path('w_eyeglass', views.f_ewomen, name='women_eyeglass'),
    path('w_categories', views.f_women, name='women'),
]