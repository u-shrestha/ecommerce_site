from . import  views
from django.urls import path
from product_detail.models import Product_info

urlpatterns = [
    path('product/<pcode>/', views.f_pdetails, name='prod_details'),
]