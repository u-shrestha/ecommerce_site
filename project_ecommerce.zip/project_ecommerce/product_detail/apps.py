from django.apps import AppConfig


class ProductDetailConfig(AppConfig):
    name = 'product_detail'
