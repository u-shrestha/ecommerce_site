from django.db import models

class Product_info(models.Model):
    pname= models.CharField(max_length=100)
    ptype=models.CharField(max_length=100)
    pcode= models.CharField(max_length=50, primary_key=True, blank=False)
    pmaterial=models.CharField(max_length=100)
    pcolor=models.CharField(max_length=50,blank=True)
    lens_width=models.CharField(max_length=10)
    bridge = models.CharField(max_length=10)
    temple = models.CharField(max_length=10)
    image= models.FileField(upload_to="product")
    price=models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return self.pname
