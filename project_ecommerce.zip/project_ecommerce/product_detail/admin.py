from django.contrib import admin

from product_detail.models import Product_info

admin.site.register(Product_info)
