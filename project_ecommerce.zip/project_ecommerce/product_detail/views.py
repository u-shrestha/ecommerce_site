from django.http import HttpResponse
from django.shortcuts import render

import product_detail
from product_detail.models import Product_info

def f_pdetails(request, pcode):
    try:
        product = Product_info.objects.get(pcode=str(pcode))
        context = {'product': product}
        return render(request, 'product_detail/pdetail.html', context)
    except Product_info.DoesNotExist:
        return HttpResponse(request, "<p> " + str(pcode) + " doesnot exist </p>")





