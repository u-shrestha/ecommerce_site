from django.contrib import admin

from user.models import User_info
from user.models import Pay_info
from user.models import Feedback

admin.site.register(User_info)
admin.site.register(Pay_info)
admin.site.register(Feedback)