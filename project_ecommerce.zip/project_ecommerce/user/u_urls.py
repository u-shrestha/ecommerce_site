from . import  views
from django.urls import path

urlpatterns = [
    path('login/', views.f_login, name='login_form'),
    path('payment/', views.f_payment, name='payment_form'),
    path('register/', views.f_register, name='register_form'),
    path('feedback/', views.f_feedback, name='feedback_form'),
]
