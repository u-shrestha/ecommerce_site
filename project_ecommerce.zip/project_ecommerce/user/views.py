from django.shortcuts import render
from django.http import HttpResponse

from user.models import User_info, Feedback
from user.models import Pay_info

def f_login(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        try:
            loginUser = User_info.objects.get(email=email, password=password)
            return HttpResponse("logged in successfully")
        except User_info.DoesNotExist:
            return HttpResponse("Username or password is not correct")
    return render(request, 'user/login.html')

def f_register(request):
    if request.method == "GET":
        return render(request, 'user/register.html')
    elif request.method== "POST":
        try:
            fname = request.POST['f_name']
            lname = request.POST['l_name']
            email = request.POST['email']
            city = request.POST['city']
            country= request.POST['country']
            password=request.POST['password']
            gender=request.POST['gender']
            Info = User_info(first_name=fname, last_name=lname, email=email, city=city, country=country, password=password, gender=gender)
            Info.save()
            return render(request, 'user/register.html', {'success' : True})
        except Exception as e:
            print("error in request")
            return  render(request, 'user/register.html', {'success': False})

def f_feedback(request):
    if request.method == "GET":
        return render(request, 'user/feedback.html')
    elif request.method== "POST":
        try:
            name = request.POST['name']
            email = request.POST['email']
            message = request.POST['message']
            Info = Feedback(name=name, email=email, message=message)
            Info.save()
            return render(request, 'user/feedback.html', {'success' : True})
        except Exception as e:
            print("error in request")
            return  render(request, 'user/feedback.html', {'success': False})


def f_payment(request):
    if request.method == "GET":
        return render(request, 'user/payment.html')
    elif request.method== "POST":
        try:
            name = request.POST['name']
            card_no = request.POST['cardno']
            exp_day = request.POST['cc_exp_no']
            exp_yr = request.POST['cc_exp_yr']
            cvc= request.POST['cvc']
            #amt=Cart.objects.get(amount=amt)
            Info = Pay_info(name=name,card_no=card_no,expd_date=exp_day,expy_date=exp_yr,cvc=cvc)
            Info.save()
            return render(request, 'user/payment.html', {'success' : True})
        except Exception as e:
            print("error in request")
            return  render(request, 'user/payment.html', {'success': False})


"""def f_search(request):
    if request.method == "POST":
        searchKey=request.post['search']
        post=Post.objects.filter(title__contains=searchKey)
        return render(request, 'home/search.html',{'search':searchKey,'data':post, 'search':True} )
        print(post)
    return  render(request, 'home/search.html')"""


