from django.db import models
from django.utils import timezone

class User_info(models.Model):
    first_name = models.CharField(max_length=100, blank=False)
    last_name = models.CharField(max_length=100, blank=False)
    email = models.EmailField(primary_key= True)
    password=models.CharField(max_length=100, blank=False)
    city = models.CharField(max_length=80)
    COUNTRY = (
        ('Uz','Uzebkistan'),
        ('Np','Nepal'),
        ('Ru','Russia'),
        ('In','India'),
        ('Af','Afghanistan'),
        ('US','United States')

    )
    country = models.CharField(max_length=2, choices=COUNTRY)

    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    submitted_date = models.DateTimeField(auto_now=True, blank=False)
    class Meta:
        ordering = ('submitted_date',)


    def __str__(self):
        return self.first_name

    pass

class Pay_info(models.Model):
    name = models.CharField(max_length=200, blank=False)
    card_no= models.IntegerField(blank=False)
    EXPD_CHOICES = (
        ('A', '01'),
        ('B', '02'),
        ('C', '03'),
        ('D', '04'),
        ('E', '05'),
        ('F', '06'),
        ('G', '06'),
        ('H','07'),
        ('I', '08'),
        ('J','09'),
        ('K','10')
    )
    expd_date = models.CharField(max_length=1, choices=EXPD_CHOICES)
    EXPY_CHOICES = (
        ('A', '2018'),
        ('B', '2019'),
        ('C','2020'),
        ('D','2021'),
        ('E', '2022')
    )
    expy_date= models.CharField(max_length=1, choices=EXPY_CHOICES)
    cvc = models.IntegerField(blank=False)
    amount= models.DecimalField(max_digits=6, decimal_places=2)
    submitted_date = models.DateTimeField(auto_now=True, blank=False)
    class Meta:
        ordering = ('submitted_date',)

    def __str__(self):
        return self.name

    pass

class Feedback(models.Model):
    name = models.CharField(max_length=100, blank=False)
    email = models.EmailField(primary_key= True)
    message=models.CharField(max_length=900, blank=False)
    submitted_date = models.DateTimeField(auto_now=True, blank=False)
    class Meta:
        ordering = ('submitted_date',)

    def __str__(self):
        return self.name

    pass