from django.shortcuts import render
from django.http import HttpResponse


def f_invoice(request):
    return render(request, 'invoice/invoice.html')

