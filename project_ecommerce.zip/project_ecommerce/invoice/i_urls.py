from . import  views
from django.urls import path

urlpatterns = [
    path('', views.f_invoice, name='invoice'),
]
