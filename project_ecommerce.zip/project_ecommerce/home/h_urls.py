from . import  views
from django.urls import path

urlpatterns = [
    path('home/', views.f_home, name='home_page'),
    path('error/', views.f_error, name='error_page'),


]