from django.shortcuts import render

from django.http import HttpResponse


def f_home(request):
    return render(request, 'home/home.html')

def f_error(request):
    return render(request, 'home/error.html')

"""def f_search(request):
    return render(request, 'home/search.html')
"""